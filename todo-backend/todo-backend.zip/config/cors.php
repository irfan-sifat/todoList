<?php

return [
    'paths' => ['api/*', 'sanctum/csrf-cookie', 'login', 'register', 'logout'],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        'https://todoapp.irfansifat.xyz',
        'http://localhost:8080', // Add your local development URL
        env('APP_URL') // Add your app URL from .env
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => true, // Change to true if using cookies/sessions
];
